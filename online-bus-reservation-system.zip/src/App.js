import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Routing from './routing/Routing';

function App() {
  return (
    <div >
      <Routing />
    </div>
  );
}

export default App;
