import React, { useState } from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { API_ENDPOINTS } from '../../api/Url_Api';
import AxiosInstance from '../../api/AxiosInstance';
import { FaGoogle, FaFacebookF, FaTwitter, FaLinkedinIn } from 'react-icons/fa'; // Importing social media icons

const RegistrationPage = () => {
    const navigate = useNavigate();
    const reg_api = API_ENDPOINTS.users;

    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        confirmPassword: '',
    });
    const [error, setError] = useState(null);
    const [successMessage, setSuccessMessage] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
        setError(null); // Clear error on change
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Check if passwords match
        if (formData.password !== formData.confirmPassword) {
            setError("Passwords do not match!");
            return;
        }

        try {
            // First, check if the email is already registered
            const checkUser = await AxiosInstance.get(`${reg_api}?email=${formData.email}`);

            if (checkUser.data.length > 0) {
                // If a user is found with the same email, show an error
                setError("This email is already registered. Please use a different email.");
            } else {
                // Proceed with registration if the email is not in use
                const response = await AxiosInstance.post(reg_api, formData);
                const token = response.data.token;

                // Check if token exists before proceeding
                if (token) {
                    localStorage.setItem('token', token);  // Save the token if registration is successful
                    setSuccessMessage('Registration successful! Please log in.');  // Show success message
                    setTimeout(() => {
                        navigate('/login');  // Redirect to login page after a short delay
                    }, 2000);
                } else {
                    setError("Registration failed. Please try again.");
                }
            }
        } catch (err) {
            setError("Registration failed. Please try again.");
        }
    };

    return (
        <div
            style={{
                background: 'linear-gradient(135deg, #ff6a00, #ee0979)',
                minHeight: '100vh',
                color: 'black',
                padding: '50px 0',
            }}
        >
            <Container>
                <Row className="text-center mb-5">
                    <Col>
                        <h1 style={{ fontSize: '3.5rem', marginTop: 50, fontWeight: 'bold', textShadow: '1px 1px 2px rgba(0, 0, 0, 0.2)' }}>Register</h1>
                        <p style={{ fontSize: '1.25rem', fontStyle: 'italic' }}>
                            Create your account to get started with our services.
                        </p>
                    </Col>
                </Row>

                <Row className="justify-content-center">
                    <Col md={6}>
                        {error && <div style={{ color: 'red', textAlign: 'center', marginBottom: '20px', fontWeight: 'bold' }}>{error}</div>}
                        {successMessage && <div style={{ color: 'green', textAlign: 'center', marginBottom: '20px', fontWeight: 'bold' }}>{successMessage}</div>}
                        <Form onSubmit={handleSubmit} style={{ backgroundColor: '#ffffff', borderRadius: '10px', padding: '30px', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
                            {['firstName', 'lastName', 'email', 'password', 'confirmPassword'].map((field, index) => (
                                <Form.Group controlId={field} key={index}>
                                    <Form.Label style={{ color: '#333', fontWeight: 'bold' }}>{field.charAt(0).toUpperCase() + field.slice(1).replace(/([A-Z])/g, ' $1')}</Form.Label>
                                    <Form.Control
                                        type={field.includes('password') ? 'password' : 'text'} // Ensure password fields are masked
                                        name={field}
                                        placeholder={`Enter your ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}`}
                                        value={formData[field]}
                                        onChange={handleChange}
                                        required
                                        style={{ borderRadius: '5px', transition: '0.3s', border: '1px solid #0072ff' }}
                                        onFocus={(e) => (e.target.style.border = '1px solid #ff6a00')}
                                        onBlur={(e) => (e.target.style.border = '1px solid #0072ff')}
                                    />
                                </Form.Group>
                            ))}

                            <div style={{ textAlign: 'center', marginTop: '20px' }}>
                                <Button
                                    type="submit"
                                    style={{
                                        backgroundColor: '#0072ff',
                                        border: 'none',
                                        color: '#fff',
                                        fontSize: '1.25rem',
                                        fontWeight: 'bold',
                                        padding: '10px 20px',
                                        borderRadius: '5px',
                                        transition: '0.3s',
                                    }}
                                    onMouseOver={(e) => (e.currentTarget.style.backgroundColor = '#005bb5')}
                                    onMouseOut={(e) => (e.currentTarget.style.backgroundColor = '#0072ff')}
                                >
                                    Register
                                </Button>
                                <p className="text-center mt-3">
                                    Already Have an Account? <Link to="/login" style={{ color: '#ff7e5f', fontWeight: 'bold' }}>Sign In here</Link>
                                </p>
                            </div>
                        </Form>

                        {/* Social Media Icons */}
                        <div style={{ textAlign: 'center', marginTop: '20px' }}>
                            <p style={{ color: '#333', fontWeight: 'bold' }}>Or sign up with</p>
                            <div className="d-flex justify-content-center">
                                {[FaGoogle, FaFacebookF, FaTwitter, FaLinkedinIn].map((Icon, index) => (
                                    <Button
                                        variant="light"
                                        className="mx-2"
                                        key={index}
                                        style={{
                                            border: '1px solid #ddd',
                                            borderRadius: '50%',
                                            width: '50px',
                                            height: '50px',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            transition: '0.3s',
                                        }}
                                        onMouseOver={(e) => (e.currentTarget.style.boxShadow = '0 0 10px rgba(0,0,0,0.2)')}
                                        onMouseOut={(e) => (e.currentTarget.style.boxShadow = 'none')}
                                    >
                                        <Icon style={{ color: '#333', fontSize: '1.5rem' }} />
                                    </Button>
                                ))}
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default RegistrationPage;
